# Handoff: Market Intelligence Dashboard

## Overview
Dashboard interno para comparar modelos de geração de imagem/vídeo (Kling, Runway, Luma, Pika, Hailuo, Veo, Sora) e camadas de API unificadoras (fal.ai, Replicate, Together AI, Baseten), com ranking ponderável por peso de critério (custo, janela de prompt, multi-shot, qualidade).

## About the design file
`dashboard-reference.html` é um **arquivo de referência de design** — HTML/CSS/JS puro, sem build step, sem dependências externas de framework. Ele demonstra layout, navegação, interações (troca de tela, sliders de peso recalculando o ranking, seletor de histórico) e os tokens visuais. **Não é para copiar direto para produção** — a tarefa é recriar este design no ambiente/stack real do projeto (React, Vue, etc., ou o framework mais adequado se ainda não houver um), usando os componentes e padrões já estabelecidos no código.

## Fidelity
**Hi-fi**: cores, tipografia, espaçamento e interações são as intencionadas. Os dados dos modelos são ilustrativos — vêm de `market-intel-agent/src/market_intel/schema.py` como formato, mas ainda sem dados reais da pipeline (`data/models/*.json` está vazio hoje).

**Atualizado**: o tema agora é dark (era claro/blueprint na primeira versão) — fundo quase preto, cards escuros arredondados, acentos coloridos (roxo/azul/teal/laranja) por KPI, fonte Inter. Ver tokens abaixo.

## Screens / Views
Uma sidebar fixa (212px) alterna entre 6 telas, sempre dentro do mesmo shell (nav superior + sidebar + main):

1. **Ranking (`overview`)** — Header com título + botão "Adjust weights". Grid de 4 KPI cards (cheapest/s, largest prompt window, best quality, multi-shot count). Lista vertical de cards de ranking (um por modelo), cada um: badge quadrado de posição, nome+provider, 3 tags (custo, prompt window, multi-shot), barra de progresso do score, caixa de score à direita. Clique no card → `Model detail`.
2. **Comparison table (`table`)** — Tabela full-width: Model, Provider, $/s, $/image, Ref imgs, Prompt window, Multi-shot (tag), Quality, Latency. Linha clicável → `Model detail`.
3. **Model detail (`detail`)** — Botão "← Back". Card hero (nome, provider, rank, score grande). Grid de 7 mini-cards de specs. Card com sparkline de 6 meses + link "View full history". Notas em texto corrido. Botão "View provider docs".
4. **Price history (`history`)** — Select de modelo. Gráfico de linha SVG (640×220) com eixo e rótulos de mês/preço min-max. Tabela abaixo: mês, $/s, variação % mês a mês.
5. **API aggregators (`aggregators`)** — Tabela: nome, badge (Current/Alternative), overhead %, uptime %, coverage (x/7), added latency, notas.
6. **Ranking weights (`config`)** — 4 sliders (0–100): cost, promptWindow, multiShot, quality. Valor atual ao lado do label. Botão "Reset to defaults". Ajustar os sliders recalcula o ranking nas outras telas imediatamente (estado compartilhado).

## Interactions & behavior
- Navegação: clique num item da sidebar troca a view visível (mostra/esconde `<section class="view">`); botão ativo ganha destaque (`.navbtn.active`).
- Selecionar um modelo (linha da tabela ou card do ranking) navega para `Model detail` com aquele modelo.
- Sliders de peso (`config`) recalculam o score de todos os modelos ao vivo — fórmula de normalização em `computeScores()` no script.
- Select de modelo em `Price history` troca o gráfico e a tabela abaixo.
- Hover em linhas de tabela e cards de ranking: leve destaque de fundo/borda.
- Responsivo: abaixo de 760px a sidebar vira uma barra horizontal rolável no topo (ver media query).

## State management
Estado único em JS (`state` object): `view` (tela atual), `selectedModelId`, `historyModelId`, `weights` ({cost, promptWindow, multiShot, quality}). No app real isso deveria virar estado de componente/contexto (React state, Zustand, etc.) — o cálculo de score deve continuar reativo aos pesos.

## Design tokens
- Fundo da página: `#0b0b0f`. Faixa superior e sidebar: `#0e0e12`. Cards: `#16161a`, borda `1px solid rgba(255,255,255,.08)`, radius 12–14px (cantos arredondados, sem marcas de registro).
- Texto: branco `#f2f2f4`, muted `#8b8b93`.
- Acentos por categoria (cada KPI/elemento usa um, não é um único accent): roxo `#8b5cf6`/`#a78bfa` (rank badges, nav ativo, score bar), azul `#3b82f6`/`#60a5fa` (chip de preço), teal `#14b8a6`/`#2dd4bf` (chip de prompt window, linhas de gráfico), laranja `#f5a524` (ícone multi-shot). Verde `#22c55e`/`#4ade80` para variação negativa de custo (bom), vermelho `#ef4444`/`#f87171` para variação positiva de custo (ruim).
- Tipografia: Inter 400/500/600/700, corpo 15px, títulos 26–34px peso 700.
- Radius: 8px em botões/inputs, 12–14px em cards, 20px (pill) em chips/tags.
- Hover: linhas de ranking e da tabela clareiam levemente o fundo/borda.

## Assets
Nenhuma imagem. Ícones são SVGs inline desenhados à mão (stroke 1.5–1.8, geométricos — círculos/retângulos/linhas), inspirados em Lucide, cada um colorido conforme o acento do KPI/nav item.

## Files
- `dashboard-reference.html` — a referência completa, standalone, abre direto no navegador.
